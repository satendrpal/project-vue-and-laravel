<template>
  <Header />
  
  <!-- <tr v-for="login in products" :key="login.id">
 
  <td><h1>Welcome:{{login.name}}</h1></td>
   </tr> -->
   
   <div class="Sidebar">
  <div id="fetch">
    <h2 class="text-center py- text-uppercase ">details List</h2>
 <h1>Welcome:{{$name}}</h1>
  
        <label></label>
        <input type="search" v-model="app.search" placeholder="Search" />
        
        <button @click="reverseMessage(app.search)">search</button>
    
    <table class="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>First_Name</th>
          <th>Last_Name</th>
          <th>Phone</th>
          <th>city</th>
          <th>State</th>
          <th>Countery</th>
          <!-- <th>Image</th> -->
        </tr>
      </thead>

      <tbody >
        <tr v-for="product in products" :key="product">
             
          <td>{{product.id}}</td>
          <td>{{ product.First_name }}</td>
          <td>{{ product.Last_name }}</td>
          <td>{{ product.phone }}</td>
          <td>{{ product.City }}</td>
          <td>{{ product.State }}</td>
          <td>{{ product.Country }}</td>
          <td>
            <img v-bind:src="`../uploads/products/${product.file}`" class="rounded-circle bg-dark" width="180" height="">
          </td>
          <td>
            <button class="btn btn-danger" @click="deleteProduct(product.id)" ><i class="fa fa-trash"></i></button>
            <!-- <button class="btn btn-danger" @click="deleteProduct(product.id)"> 
              Delete
            </button>-->
            <!-- <button class="btn btn-success" @click="Edit(product.id)" ><i class="fa fa-edit"></i></button> -->
            <div class="btn-group" role="group">
              <router-link
                :to="{ name: 'Edit', params: { id: product.id } }"
                class="btn btn-success"
                ><i class="fa fa-edit"></i></router-link
              >
            </div>
            
          </td>
        </tr>
        
      </tbody>
    </table>
     
  </div>
  
   </div>
    <pagination align="center" class="page" :data="users" @pagination-change-page="list">
      
    </pagination>

       
</template>

<script>

import Header from "./Header.vue";

import axios from "axios";
export default {
  name: "Fetch",
  components: {
    Header,
 
  },
  data() {
    return {
       type:Object,
       default:null,
      products: [],
      app:{
        search:"",
      },
    };
  },
  mounted() {
    console.log("mounted");
  },
  created() {
    axios
      .get("/api/jointable")
      .then((response) => {
        this.products = response.data.data;
        console.log(this.products);
      })
      .catch((error) => {
        console.log(error);
        this.products = [];
      });
  },
  methods: {
    deleteProduct(id) {
      axios.delete(`/api/delete/${id}`).then((response) => {
        let i = this.products.map((data) => data.id).indexOf(id);
        this.products.splice(i, 1);
        location.reload();
        this.$router.push({ name: "Addpage" });
      });
    },
  },
   
   methods:{
            async list(page=1){
                await axios.get(`/api/paginate?page=${page}`).then(({data})=>{
                    
                   this.users = data.data
                   console.log("hii", this.users)
                }).catch(({ response })=>{
                    console.error(response)
                });
            },
 created() {
    
  },
   },
   methods: {
    reverseMessage() {
      console.log(this.app.search,"hii")
      axios.get(`/api/search?First_name=${this.app.search}`).then((response) => {
          this.products = response.data.data
        console.log( this.products,"book")
          this.$router.push({ name: "Fetch" });
         

    });
    },
  },
};
</script>
<style>
h1{
  margin-left: 70%;
}
.page{
  margin-left: 30%;
}
</style>
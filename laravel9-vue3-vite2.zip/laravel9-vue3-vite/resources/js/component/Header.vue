<template>
<h1>lksjf</h1>
<Siderbar />
<div id="app">

  <fixed-header>
    <div class="container fixed-top" id="header">
      <div class="row">
        <nav class="navbar navbar-light bg-dark fixed-top">
          <div class="container-fluid">
            <!-- <router-link
              class="navbar-brand text-info"
              :to="{ name: 'Addpage' }"
              >Add_Page</router-link
            >
            <router-link class="navbar-brand text-info" :to="{ name: 'Fetch' }"
              >All Data</router-link
            > -->
            <form @submit.prevent="Logout">
            
              <div class="dropdown">
         <!-- <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
     User
        </button> -->
         <button class="btn btn-info  " type="submit" id="logout">Logout</button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
  </ul>
</div>
            </form>
          </div>
        </nav>
      </div>
    </div>
    <router-view></router-view>
  </fixed-header>
</div>
</template>

<script>
import Siderbar from './Sidebar.vue'
import Footer from './Footer.vue'

export default {
  name: "Logout",
components:{
  Siderbar,
  Footer,
  
  
},
  methods: {
    Logout() {
      axios.post(`/api/logout`).then((res) => {
        this.$router.push({ name: "Login" });
      });
    },
  },
 
};
</script>
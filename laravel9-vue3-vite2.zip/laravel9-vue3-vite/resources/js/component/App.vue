<template>
    <!-- <router-link to ="/login"> Login</router-link> -->
  <router-view></router-view>
</template>
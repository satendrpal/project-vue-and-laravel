<template>
<div id="gallery">
    <div class="container">
        <div class="row">
            <div class="col-md-12 py-4">
                <h1>GALLERY</h1>
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery1.jpg' "
                      alt="..."
                    />
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery2.jpg' "
                      alt="..."
                    />
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery3.jpg' "
                      alt="..."
                    />
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery4.jpg' "
                      alt="..."
                    />
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery5.jpg' "
                      alt="..."
                    />
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery6.jpg' "
                      alt="..."
                    />
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery7.jpg' "
                      alt="..."
                    />
            </div>
            <div class="col-sm-3 img rooms">
                 <img
                      :src="'/uploads/products/gallery8.jpg' "
                      alt="..."
                    />
            </div>
        </div>
    </div>
</div>
</template>
<script>
export default {
    
}
</script>
<style>

.img{
   
      padding-bottom: 2%;
}
</style>
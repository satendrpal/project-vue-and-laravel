import './bootstrap';

import {createApp} from 'vue'
import router from './component/router.js'
import App from './component/App.vue'
import { faPhone } from "@fortawesome/free-solid-svg-icons";



createApp(App).use(router).component("font-awesome-icon", faPhone).mount("#app")

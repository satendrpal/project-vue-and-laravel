<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Hash;
use Validator;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Addpage;
use JWTAuth;
class Authcontroller extends Controller
{
    public function create(Request $request){
        $user = new User;
        $user->name= $request->name;
        $user->email= $request->email;
        $user->password= hash::make($request->password);
        $user->save();
        return $user;
    }



    public function Login(Request $request)
       
    {  
        $token = JWTAuth::getToken(); 
        $apy = JWTAuth::getPayload($token)->toArray();
        dd($apy);
    //    if(){

       
    //     $validator = validator::make($request->all(),[
    //         'email'=>'required',
    //         'password'=>'required'
    //     ]);
    //     if($validator->fails()){
    //         return response()->json($validator->errors(),422);
    //     }
    //     if(!$token=auth()->attempt($validator->validated())){
    //         return response()->json(['error'=>'Unauthorized'],401);
    //     }else{
    //         return redirect()->back();
    //     }
    // // }
    // return $this->createNewToken($token);
    }
    
    public function createNewToken($token){
        return response()->json([
            'access_token'=>$token,
            'token_type'=>'bearer',
            'expires_in'=>auth()->factory()->getTTL()*60,
            'user'=>auth()->user()
    
    ]);
    }







    public function register(Request $request){
   
        
        $validator =Validator::make($request->all(),[
            
            'name'=>'required|string',
            'email'=>'required|unique:users',
            'password'=>'required'
        ]);
          
        if($validator->fails()){
            return response()->json($validator->errors()->toJson(),400);
    
        }
       $user = User::create([
             'name'=>$request->name,
             'email'=>$request->email,
             'password'=>hash::make($request->password),
            
       ]);
       if($user){
        return response()->json([
            'status' => '200',
            'data' =>  $user,
           
              'name'=>$user->name,
            'success'=>'succesffuly',
            'msg' => 'Add succesffuly'
        ]);
    }else {
        $response = ["message" =>'User does not exist'];
        return response($response, 422);
    }
      
       $token = JWTAuth::fromUser($user);   
           
       return back()->with('success','Item created successfully!');  
    //    return response()->json(compact('user','token'),201);
       
    //     return response()->json(['message'=>'User user_comapnysuccessfully registerd','user'=>$user],201);
       
    }








    public function path (Request $request) {
        $validator = Validator::make($request->all(), [
                
            'email' => 'required|string|email|max:255',
            'password' => 'required|min:3',
        ]);
        if ($validator->fails())
        {
            return response(['errors'=>$validator->errors()->all()], 422);
        }
        $user = User::where('email', ($request->email))->first();
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                $token = $user->createToken('Laravel Password Grant Client')->accessToken;
                $response = ['token' => $token];
                return response()->json([
                    'msg'=>'succesfull',
                    'data'=>$user,
                    'name'=>$user->name
                ]);
            } else {
                $response = ["message" => "Password does not exist"];
                return response($response, 422);
            }
        } else {
            $response = ["message" =>'Email does not exist'];
            return response($response, 422);
        }
    }

public function logout(Request $request){
    
    $request->user()->token()->revoke();
    return response()->json([
        'message' => 'Successfully logged out'
    ]);


  }




  public function resetPassword(Request $request)
    {
        
        $credentials = request()->validate([
            'email' => 'required|email',
            // 'token' => 'required|string',
            'password' => 'required|string|confirmed'
        ]);
    
        $reset_password_status = Password::reset($credentials, function ($user, $password) {
            $user->password = bcrypt($password);
            $user->save();
        });

        if ($reset_password_status == Password::INVALID_TOKEN) {
            return ['success' => false];
        }

        return ['success' => true];
    }



public function updatepassword(Request $request ,$id){
             
  
   
//    $product=User::find($id);
   
   if(!hash::check($request->currect_password,user()->password))
   {
   return back()->with("Error","Currect password not match");

}
User::whereId(auth()->user()->id)->update([
    'password' => Hash::make($request->New_password)
]);

return back()->with("status", "Password changed successfully!");
}




public function search(Request $request )
{
   
    $query = $request->First_name;
    $products = Addpage::where('First_name', 'like', '%' . $query . '%')
        ->orWhere('Last_name', 'like', '%' . $query . '%')
        ->get();

   

    return response()->json([
        'data'=> $products,
    ]);
     
}
}

